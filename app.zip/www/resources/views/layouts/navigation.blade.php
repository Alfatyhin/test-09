<nav>

    <a class="button" href="{{ route('index') }}" >
        Сетка
    </a>
    <a class="button" href="{{ route('staff_index') }}" >
        Сотрудники
    </a>
    <a class="button" href="{{ route('departaments_index') }}" >
        Отделы
    </a>

</nav>
