<?php $__env->startSection('title', 'departament-add'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php if(isset($departament)): ?>
        <h2> Редактировать </h2>
        <?php else: ?>
            <h2> Создать отдел </h2>
        <?php endif; ?>

        <form action="<?php if(isset($departament)): ?>
        <?php echo e(route('departaments_update', ['departament' => $departament])); ?>

            <?php else: ?>
        <?php echo e(route('departaments_add')); ?>

        <?php endif; ?>" method="get">

            <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td>
                    Имя
                </td>
                <td>

                    <input id="name" type="text" name="name"
                           class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php if(isset($departament->name)): ?><?php echo e($departament->name); ?><?php endif; ?>" />

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </td>
            </tr>


            <tr>
                <td colspan="2">

                    <?php if(isset($departament)): ?>
                        <input class="button" type="submit" value="изменить" />
                    <?php else: ?>
                        <input class="button" type="submit" value="добавить" />
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        </form>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer5.3.5\OSPanel\domains\clients\test-work-09\www\resources\views/departaments/add.blade.php ENDPATH**/ ?>