<?php $__env->startSection('title', 'departaments'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
       <h2>Отделы</h2>

        <p>
            <a class="button" href="<?php echo e(route('departaments_create')); ?>"> добавить отдел </a>
        </p>
        <table>
            <tr>
                <th>
                    Отдел
                </th>
                <th>
                    Количество сотрудников
                </th>
                <th>
                    Максимальная заработная плата
                </th>
                <th>

                </th>

            </tr>


                <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($departament->name); ?>

                    </td>
                    <td>
                        <?php echo e($departament->staff_count); ?>

                    </td>
                    <td>
                        <?php echo e($maxSalary[$departament->id]); ?>

                    </td>
                    <td>
                        <a class="button" href="<?php echo e(route('departaments_edit', ['departament' => $departament])); ?>">редактировать</a>
                        <br>
                        <a class="button" href="<?php echo e(route('departaments_delete',  ['departament' => $departament])); ?>">удалить</a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer5.3.5\OSPanel\domains\clients\test-work-09\www\resources\views/departaments/index.blade.php ENDPATH**/ ?>