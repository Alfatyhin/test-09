<nav>

    <a class="button" href="<?php echo e(route('index')); ?>" >
        Сетка
    </a>
    <a class="button" href="<?php echo e(route('staff_index')); ?>" >
        Сотрудники
    </a>
    <a class="button" href="<?php echo e(route('departaments_index')); ?>" >
        Отделы
    </a>

</nav>
<?php /**PATH D:\OpenServer5.3.5\OSPanel\domains\clients\test-work-09\www\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>